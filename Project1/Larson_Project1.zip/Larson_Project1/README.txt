To run my program, simply run ./Project1.exe.

Problem analysis:

Problems 1 and 2 are typical "easy" LPs which have optimal values of 21 and
30, respectively.

Problem 3 Has no solution because of the constraint x1 < -5. This means
there are no points within the FR which meet the nonnegativity conditions.

Problem 4 is another typical "easy" LP, after the constraints have been
adjusted to fit the cononical form. My program does this (in all problems
where necessary) by requiring the user to input the matrix of coefficients
of the constraints such that every constraint is <=.

Problem 5 has constraints made up entirely of vertical lines. This means the
FR is unbounded. *

Problem 6 is a typical "easy" LP with the caveat that the FR does not include
the origin; it is instead lower-bouned by a line other than the y-axis. *

Problem 7 has only one constraint and thus by definition has infinitely many
solutions along that line.

* You'll see (0,0) listed under "Intersections" for every problem. This is a
result in a quirk in my program's organization. I decided that the time to
fix this little output hiccup wasn't worth it, considering the program's
mathematical process is still entirely correct.